<?php include 'includes/header.php'; ?>

<h1>Services</h1>
<p>Coming Soon</p>

<?php include 'includes/footer.php'; ?>
