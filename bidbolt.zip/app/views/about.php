<?php include 'includes/header.php'; ?>

<h1>About Us</h1>
<p>BidBolt is your go-to platform for streamlining procurement and tendering solutions in Egypt's construction market. We connect trusted vendors and subcontractors with construction companies to build lasting partnerships.</p>

<?php include 'includes/footer.php'; ?>
