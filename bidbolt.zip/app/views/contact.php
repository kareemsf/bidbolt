<?php include 'includes/header.php'; ?>

<h1>Contact Us</h1>
<form action='#' method='post'>
    <input type='text' placeholder='Your Name' style='padding: 10px; margin-right: 10px;'>
    <input type='email' placeholder='Your Email' style='padding: 10px; margin-right: 10px;'>
    <textarea placeholder='Your Message' style='padding: 10px;'></textarea><br><br>
    <button type='submit' style='padding: 10px 20px; background-color: white; color: #1e73be;'>Send</button>
</form>

<?php include 'includes/footer.php'; ?>
